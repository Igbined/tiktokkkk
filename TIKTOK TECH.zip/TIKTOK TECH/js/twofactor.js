// DOM Elements
const inputs = document.querySelectorAll('.code-input');
const countdownEl = document.getElementById('countdown');
const resendTextEl = document.getElementById('resend-text');
const resendBtnEl = document.getElementById('resend-btn');

let timer = 42;
let timerInterval = null;

// Auto-advance and digit input management
inputs.forEach((input, index) => {
    // Keydown event for handling backspace & arrow navigation
    input.addEventListener('keydown', (e) => {
        if (e.key === 'Backspace') {
            if (!input.value && index > 0) {
                inputs[index - 1].focus();
                inputs[index - 1].value = '';
            } else {
                input.value = '';
            }
            e.preventDefault();
        } else if (e.key === 'ArrowLeft' && index > 0) {
            inputs[index - 1].focus();
        } else if (e.key === 'ArrowRight' && index < inputs.length - 1) {
            inputs[index + 1].focus();
        }
    });

    // Input event for typing digits and auto-advancing
    input.addEventListener('input', (e) => {
        const value = e.target.value;

        // Handle pasted multiple digits (e.g., 6-digit code pasted)
        if (value.length > 1) {
            const digits = value.replace(/\D/g, '').split('');
            digits.forEach((digit, idx) => {
                if (index + idx < inputs.length) {
                    inputs[index + idx].value = digit;
                }
            });
            const lastFilledIndex = Math.min(index + digits.length - 1, inputs.length - 1);
            inputs[lastFilledIndex].focus();
            return;
        }

        // Accept only numeric characters
        if (!/^[0-9]$/.test(value)) {
            input.value = '';
            return;
        }

        // Advance to next input
        if (value && index < inputs.length - 1) {
            inputs[index + 1].focus();
        }
    });

    // Auto-select text on focus
    input.addEventListener('focus', () => {
        input.select();
    });
});

// Countdown Timer Logic
function startResendTimer() {
    timer = 60;
    resendTextEl.classList.remove('hidden');
    resendBtnEl.classList.add('hidden');
    countdownEl.textContent = timer;

    clearInterval(timerInterval);
    timerInterval = setInterval(() => {
        timer--;
        countdownEl.textContent = timer;

        if (timer <= 0) {
            clearInterval(timerInterval);
            resendTextEl.classList.add('hidden');
            resendBtnEl.classList.remove('hidden');
        }
    }, 1000);
}

// Start initial countdown from 42s as shown in screenshot
function initCountdown() {
    timer = 42;
    countdownEl.textContent = timer;
    timerInterval = setInterval(() => {
        timer--;
        countdownEl.textContent = timer;

        if (timer <= 0) {
            clearInterval(timerInterval);
            resendTextEl.classList.add('hidden');
            resendBtnEl.classList.remove('hidden');
        }
    }, 1000);
}

// Initialize on load
window.addEventListener('DOMContentLoaded', () => {
    initCountdown();
    inputs[0].focus();
});
